// Please don't change the pre-written code
// Import the necessary modules here

export const createNewJob = async (job) => {
  // Write your code here
};

export const applyJobRepo = async (jobId, userId) => {
  // Write your code here
};
export const findJobRepo = async (_id) => {
  // Write your code here
};
