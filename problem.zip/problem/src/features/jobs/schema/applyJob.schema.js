// Please don't change the pre-written code
// Import the necessary modules here

export const applyJobSchema = new mongoose.Schema({
  // Write your code here
});
